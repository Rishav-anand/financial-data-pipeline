# Script to fetch exchange rates
