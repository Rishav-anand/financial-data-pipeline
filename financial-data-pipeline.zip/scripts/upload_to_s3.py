# Script to upload data to S3
