# PySpark job for currency normalization
