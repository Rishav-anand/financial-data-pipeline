# Script to generate sample bank transaction data
